// src/pages/About.js
import React from 'react';

const About = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>This is the about us content.</p>
    </div>
  );
};

export default About;
