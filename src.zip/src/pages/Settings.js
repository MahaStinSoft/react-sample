import React from 'react';

const Settings = () => {
  return (
    <div>
      <h2>Settings</h2>
      <p>Adjust your preferences here.</p>
    </div>
  );
};

export default Settings;
